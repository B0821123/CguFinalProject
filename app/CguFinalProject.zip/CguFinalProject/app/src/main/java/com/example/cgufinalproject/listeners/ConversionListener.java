package com.example.cgufinalproject.listeners;

import com.example.cgufinalproject.models.User;

public interface ConversionListener {
    void onConversionClicked(User user);
}
