package com.example.cgufinalproject.models;

import java.util.Date;

public class ChatMessage { // 在database中的chat集合
    public String senderId, receiverId, message, dateTime;
    public Date dateObject;
    public String conversionId, conversionName, conversionImage;
}
