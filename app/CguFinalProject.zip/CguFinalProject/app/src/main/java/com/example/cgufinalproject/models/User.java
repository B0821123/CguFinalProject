package com.example.cgufinalproject.models;

import java.io.Serializable;

public class User implements Serializable { // 在database中的users集合
    public String name, image, email, token, id;
}
